//
//  User.swift
//  Dog Walker
//
//  Created by Thiago T Nogueira on 16/03/16.
//  Copyright © 2016 FIAP. All rights reserved.
//

import UIKit

struct User {

    var id = ""
    var cellphone = ""
    var description = ""
    var email = ""
    var gender = ""
    var location = ""
    var name = ""
    var picture = ""
    var profile = ""
    var rating = ""
    var status = ""
}
