//
//  Scheduling.swift
//  Dog Walker
//
//  Created by Thiago T Nogueira on 28/03/16.
//  Copyright © 2016 FIAP. All rights reserved.
//

import UIKit

struct Scheduling {
    var id = ""
    var date = ""
    var dogSize = ""
    var duration = ""
    var status = ""
    var time = ""
    var walkerId = ""
}
