//
//  CurrentUser.swift
//  Dog Walker
//
//  Created by Usuário Convidado on 22/03/16.
//  Copyright © 2016 FIAP. All rights reserved.
//

import UIKit

class CurrentUser: NSObject {

    static var uid: String = ""
}
